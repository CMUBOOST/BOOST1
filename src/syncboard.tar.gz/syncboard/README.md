This package allows an arduino uno to be used for hardware time synchronization of sensors. There are two modes of operation: 1) network trigger where any node can send a trigger service request 2) continuous triggering which is started and stopped with a service request.

1) Open syncboard/arduino/syncboard/syncboard.ino in the arduino IDE and upload to an arduino UNO

2) If the arduino is connected to /dev/ttyACM0 then start the node: $rosrun syncboard syncboard_node

   you may need to set permisssions: $sudo chmod 777 /dev/ttyACM0

3) Send a network trigger signal:    $rosservice call /trigger

   Or start continuous triggering:   $rosservice call /start_continuous
   
   To stop continuous triggering:    $rosservice call /stop_continuous

4) Change the continuous triggering frequency by sending the arduino a "c" byte then following directions (using cutecom, arduino IDE serial debugger, etc.)
