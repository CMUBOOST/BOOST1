#include "ros/ros.h"
#include "std_srvs/Trigger.h"
#include "std_msgs/String.h"
#include <cstdio>
#include <string>
#include <sstream>
#include <iostream>
#include "serial/serial.h"

#define NMEA_LENGTH 33

std::string to_string(int i){
  std::ostringstream os;
  os << i;
  return os.str();
}

serial::Serial syncboard;
bool continuous_started = false;
ros::Publisher timestamps_pub;

bool handshake(){
  int counter = 0;
  while(ros::ok()){
    syncboard.flush();
    syncboard.write("h");
    std::string result = syncboard.readline();
    if (result.length() > 0){
      ROS_INFO("Connected to syncboard.");
      return true;
    }
    if(counter++ > 50){
      ROS_WARN_ONCE("Connecting to syncboard is taking longer than expected.");
    }
    ros::Rate(10).sleep();
  }
  ROS_WARN("Syncboard handshake failed.");
  return false;  
}

bool read_nmea_string(std::string *return_string){
  while(syncboard.available() > 0){
    try{
      std::string nmea_string = syncboard.readline();
      int start_pose = nmea_string.find("$");
      if (start_pose >= 0){
        nmea_string = nmea_string.substr(start_pose);
        *return_string = nmea_string;
        return true;
      }  
    }
    catch (int excepton){
      ROS_ERROR_STREAM("An exception occurred while reading from serial port:" << excepton);
      *return_string = excepton;
      return false;
    } 
  }
  ROS_ERROR("Error parsing NMEA string.");
  *return_string = "Error parsing NMEA string.";
  return false;
}

void publish_nmea_string(std::string nmea_string){
  std_msgs::String nmea_msg;
  ros::Time computer_stamp = ros::Time::now();
  std::string syncbox_stamp = nmea_string.substr(7,9);
  std::string description = ":(syncbox_seconds computer_seconds computer_nanoseconds)"; 
  std::string msg_str = syncbox_stamp +":"+ to_string(computer_stamp.sec) +":"+ to_string(computer_stamp.nsec) + description; //TODO change this format (requires changing pgr_camera)
  nmea_msg.data = msg_str;
  timestamps_pub.publish(nmea_msg);
}

bool trigger_callback(std_srvs::Trigger::Request  &req, std_srvs::Trigger::Response &res)
{
  syncboard.write("t");
  std::string nmea_string;
  ros::Time timeout = ros::Time::now() + ros::Duration(1);
  while(ros::Time::now() < timeout){
    if (syncboard.available() > NMEA_LENGTH) {
      if(read_nmea_string(&nmea_string)){
        res.success = true; 
        publish_nmea_string(nmea_string);
        res.message = nmea_string;
        return true;
      }
      else{ 
        res.message = nmea_string;
        res.success = false; 
        return true;
      }
    }
  }
  res.message = "Timed out waiting for NMEA message.";
  res.success = false; 
  return true;
}

bool start_continuous_callback(std_srvs::Trigger::Request  &req, std_srvs::Trigger::Response &res)
{
  syncboard.write("r");
  res.success = true; 
  res.message = "Started syncboard continuous trigger";
  continuous_started = true;
  return true;
}

bool stop_continuous_callback(std_srvs::Trigger::Request  &req, std_srvs::Trigger::Response &res)
{
  syncboard.write("s");
  res.success = true; 
  res.message = "Stopped syncboard continuous trigger";
  continuous_started = false;
  return true;
}

bool burst_callback(std_srvs::Trigger::Request  &req, std_srvs::Trigger::Response &res)
{
  syncboard.write("b");
  res.success = true; 
  res.message = "Started syncboard continuous trigger";
  continuous_started = true;
  return true;
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "syncboard_node");
  ros::NodeHandle nh;
  ros::ServiceServer trigger_service = nh.advertiseService("trigger", trigger_callback); 
  ros::ServiceServer start_continuous_service = nh.advertiseService("start_continuous", start_continuous_callback); 
  ros::ServiceServer stop_continuous_service = nh.advertiseService("stop_continuous", stop_continuous_callback); 
  ros::ServiceServer burst_service = nh.advertiseService("burst", burst_callback); 
  timestamps_pub = nh.advertise<std_msgs::String>("syncbox_timestamps", 1);
  std::string port;
  int baud;
  nh.param<std::string>("port", port, "/dev/ttyACM0");
  nh.param("baud", baud, 115200);
  syncboard.setTimeout(serial::Timeout::max(), 500, 0, 500, 0);
  syncboard.setPort(port);
  syncboard.setBaudrate(baud);
  syncboard.open();
  handshake();
  while(ros::ok()){
    if (continuous_started and syncboard.available() > NMEA_LENGTH) {
      std::string nmea_string;
      if(read_nmea_string(&nmea_string)){
        publish_nmea_string(nmea_string);
      }
    }
    ros::spinOnce();
    ros::Rate(100).sleep();
  }
  syncboard.write("s");
  return 0;
}
